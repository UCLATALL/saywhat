const apiURL = 'https://say-what-backend.herokuapp.com';
var timers = {};

chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason == 'install') {
        chrome.storage.local.set({
            userID: Date.now()
        });
    }
});

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.type == 'startCounting') {
        timers[sender.tab.id] = {
            url: sender.tab.url,
            pageName:message.pageName,
            started: Date.now()
        };
    }
});

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
    if (!!changeInfo.url) {
        if (!!timers[tabId] && timers[tabId].url != changeInfo.url) {
            sendTime(timers[tabId], Date.now(), tabId);
        }
    }
});

chrome.tabs.onRemoved.addListener(function (tabId, removeInfo) {
    if (!!timers[tabId]) {
        sendTime(timers[tabId], Date.now(), tabId);
    }
});

chrome.tabs.onReplaced.addListener(function (addedTabId, removedTabId) {
    if (!!timers[removedTabId]) {
        timers[addedTabId] = timers[removedTabId];
        delete timers[removedTabId];
    }
});

function sendTime(timer, endTime, tabId) {
    chrome.storage.local.get('userID', function (u) {
        if (!!u.userID) {
            $.post(apiURL + '/addTime', {
                pageURL: timer.url,
                pageName:timer.pageName,
                secondsSpent: (endTime - timer.started) / 1000,
                userID: u.userID
            }).done(
                function (data) {
                    if (!!data.ok) {
                        delete timers[tabId];
                    }
                }).fail(function (xhr, status, error) {
                sendTime(timer, endTime, tabId);
            });
        }
    });
}