const apiURL = 'https://say-what-backend.herokuapp.com';
var lastPosition;

chrome.runtime.sendMessage({
    'type': 'startCounting',
    'pageName':$("#breadcrumbs li").eq(-1).text()
});

$(".user_content p").wrap('<div class="swWrapper"></div>');

refreshPanes();

$(".swWrapper").on('mouseover', function (e) {
    $('.swPanel:not(.commented)').css('visibility', 'hidden');
    $(this).find('p').next().css('visibility', 'visible');
});

$(document).on('mouseover', function (e) {
    if (!$(e.target).hasClass('swPanel') && !$(e.target).hasClass('swWrapper') && !$(e.target).hasClass('user_content') && !$(e.target).is('p') && !$(e.target).parent().is('p') && !$(e.target).parent().parent().is('p') && !$(e.target).parent().hasClass('swPanel')) {
        $('.swPanel:not(.commented)').css('visibility', 'hidden');
    }
});

$(document).on('click', function (e) {
    if (!$(e.target).hasClass('swButton') && ($(e.target).hasClass('swCancelBtn') || !$(e.target).parents('#myModal').length)) {
        $('#myModal').remove();
    }
});

$(document).on('click', ".swButton", function () {
    lastPosition = $('.swWrapper').index($(this).parent().parent()) + 1;
    showModal($(this).parent());
});

$(document).on('click', ".swDeleteBtn", function () {
    let commentID = $("#myModal").attr('data-commentId');
    chrome.storage.local.get("comments", function (c) {
        if (!!c.comments) {
            for (i = 0; i < c.comments.length; i++) {
                if (c.comments[i].id == commentID) {
                    deleteComment(c.comments, commentID, i);
                }
            }
        }
    });
});

$(document).on('click', '.swSaveBtn', function () {
    $(this).prop('disabled', true);
    let rating = null;
    let paragraphBefore = "";
    let paragraphAfter = "";

    if (!!$(".activeReaction").length) {
        rating = $(".activeReaction").attr('data-reaction');
    }

    if (lastPosition - 2 >= 0) {
        if (!!$(".user_content p").eq(lastPosition - 2).text()) {
            paragraphBefore = $(".user_content p").eq(lastPosition - 2).text();
        } else {
            paragraphBefore = "IMAGE";
        }
    }

    if ($(".user_content p").length > lastPosition) {
        if (!!$(".user_content p").eq(lastPosition).text()) {
            paragraphAfter = $(".user_content p").eq(lastPosition).text();
        } else {
            paragraphAfter = "IMAGE";
        }
    }

    let newComment = {
        'comment': $(".myComment").val(),
        'rating': rating,
        'paragraphContent': $("#myModal").attr('data-paragraphContent'),
        'url': window.location.href.split(/[?#]/)[0],
        'position': lastPosition,
        'paragraphText': $(".user_content p").eq(lastPosition - 1).text(),
        'paragraphBefore': paragraphBefore,
        'paragraphAfter': paragraphAfter,
        'pageName': $("#breadcrumbs li").eq(-1).text()
    };

    let commentID = $("#myModal").attr('data-commentId');

    chrome.storage.local.get("comments", function (c) {
        if (!!c.comments) {
            let found = false;
            for (i = 0; i < c.comments.length; i++) {
                if (c.comments[i].id == commentID) {
                    if ($(".myComment").val() != "") {
                        c.comments[i].comment = $(".myComment").val();
                        c.comments[i].rating = rating;
                        c.comments[i].paragraphBefore = paragraphBefore;
                        c.comments[i].paragraphAfter = paragraphAfter;
                        c.comments[i].pageName = $("#breadcrumbs li").eq(-1).text();
                        c.comments[i].position = lastPosition;
                        editComment(c.comments, c.comments[i], i);
                    } else {
                        deleteComment(c.comments, commentID, i);
                    }
                    found = true;
                }
            }

            if (!found) {
                addComment(c.comments, newComment);
            }
        } else {
            addComment([], newComment);
        }
    });
});

$(document).on('click', ".swSmiley", function () {
    $(this).parent().siblings().find('.activeReaction').removeClass('activeReaction');
    $(this).toggleClass('activeReaction');
});

$(document).keyup(function (e) {
    if (e.keyCode == 27) { // escape key maps to keycode `27`
        $("#myModal").remove();
    }
});

function showModal(swPanel) {
    // append modal to document body
    $('body').append(`<div id="myModal" class="modal"><div id="modal-content" class="modal-content">
    <p><b>How understandable is this paragraph?</b></p>
    <div class='smileysDiv'>
    <div class='swReaction'><div class='swSmiley sw1' data-reaction='1'></div></div>
    <div class='swReaction'><div class='swSmiley sw2' data-reaction='2'></div></div>
    <div class='swReaction'><div class='swSmiley sw3' data-reaction='3'></div></div>
    <div class='swReaction'><div class='swSmiley sw4' data-reaction='4'></div></div>
    <div class='swReaction'><div class='swSmiley sw5' data-reaction='5'></div></div>    
    </div>
    <div><b><span class='confusingSpan'>Confusing</span><span class='clearSpan'>Clear</span></b></div>
    <br><br>
    <p style='text-align:left !important;float:left !important;font-weight:bold !important;'>Question/comment:</p>
    <textarea class='myComment'></textarea>
    <br>
    <div class='buttonsDiv'>
    <button class='btn swCancelBtn'>Cancel</button>
    <button class='btn swSaveBtn'>Save</button>
    </div>
    </div></div>`);


    // Get the modal
    let modal = $('#myModal');

    if (!!$(swPanel).attr('data-commentId')) {
        $(".myComment").text($(swPanel).attr('data-comment'));
        $(modal).attr('data-commentId', $(swPanel).attr('data-commentId'));
        $('.swSaveBtn').before(`<button class='btn swDeleteBtn'>Delete</button>`);
    }

    if (!!$(swPanel).attr('data-reaction')) {
        $(".sw" + $(swPanel).attr('data-reaction')).addClass('activeReaction');
    }

    $(modal).attr('data-paragraphContent', $(swPanel).prev().html().trim().replace(/style="[^"]*"/g, ""));

    // Open the modal 
    $(modal).show();
}

function refreshPanes() {
    $('.swPanel').remove();
    $(".user_content p").after('<div class="swPanel"><button class="swButton">?!!</button></div>');
    for (i = 0; i < $('.swPanel').length; i++) {
        $(".swPanel").eq(i).css('height', $(".swPanel").eq(i).prev().height() + 'px');
    }
    $('.swPanel').css('visibility', 'hidden');
    $('#myModal').remove();

    chrome.storage.local.get("comments", function (c) {
        if (!!c.comments) {
            for (i = 0; i < c.comments.length; i++) {
                if (c.comments[i].url == window.location.href.split(/[?#]/)[0]) {
                    let paragraph;
                    let pars = $(".user_content p");
                    for (j = 0; j < $(pars).length; j++) {
                        if ($(pars).eq(j).html().replace(/style="[^"]*"/g, "") == c.comments[i].paragraphContent) {
                            paragraph = $(pars).eq(j);
                        }
                    }
                    if (!!paragraph && $(paragraph).length) {
                        let swPanel = $(paragraph).next();
                        $(swPanel).attr('data-commentId', c.comments[i].id);
                        $(swPanel).attr('data-reaction', c.comments[i].rating);
                        $(swPanel).attr('data-comment', c.comments[i].comment);
                        $(swPanel).addClass('commented');
                    }
                }
            }
        }
    });
}

function addComment(comments, comment) {
    $.post(apiURL + '/addComment', {
        comment: comment
    }).done(
        function (data) {
            if (!!data.commentID) {
                comment.id = data.commentID;
                comments.push(comment);
                chrome.storage.local.set({
                    comments: comments
                }, function () {
                    refreshPanes();
                });
            }
        }).fail(function (xhr, status, error) {
        addComment(comments, comment)
    });
}

function deleteComment(comments, commentID, index) {
    $.post(apiURL + '/deleteComment', {
        commentID: commentID
    }).done(
        function (data) {
            if (!!data.deleted) {
                comments.splice(index, 1);
                chrome.storage.local.set({
                    comments: comments
                }, function () {
                    refreshPanes();
                });
            }
        }).fail(function (xhr, status, error) {
        deleteComment(comments, commentID);
    });
}

function editComment(comments, comment, index) {
    $.post(apiURL + '/editComment', {
        comment: comment
    }).done(
        function (data) {
            if (!!data.edited) {
                chrome.storage.local.set({
                    comments: comments
                }, function () {
                    refreshPanes();
                });
            }
        }).fail(function (xhr, status, error) {
        editComment(comments, comment, index);
    });
}